package com.bHtmlCssProject.Main;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HtmlMainController {
	
	@RequestMapping("/")
	public String Tritibute() {
		return "tritibute";
		
	}

}
